export const environment = {
  production: true,
  SERVER_URL: 'http://localhost:3000/api',
};
